---
template: blog-post
title: Plant on my desk is a friend
slug: /post-no-image
date: 2020-05-11 08:40
description: Post with no image
featuredImage: /assets/annie-spratt-hx_hf2lppuu-unsplash.jpg
---

Hello i am post without an image
