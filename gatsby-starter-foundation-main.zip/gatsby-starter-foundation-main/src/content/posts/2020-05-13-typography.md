---
title: Typography
template: blog-post
date: 2020-05-13 09:19
slug: /typography
featuredImage: /assets/alexander-andrews-zw07kvdahpw-unsplash.jpg
description: metaphorically make a deal with the devil
---

\# When will that be?\
\
I haven't felt much of anything since my guinea pig died. Oh, but you can. But you may have to metaphorically make a deal with the devil. And by "devil", I mean Robot Devil. And by "metaphorically", I mean get your coat.\
\
We'll go deliver this crate like professionals, and then we'll go home. Leela, are you alright? \_\_You got wanged on the head.\_\_ \*Dear God, they'll be killed on our doorstep!\* And there's no trash pickup until January 3rd.\
\

## Bender, you risked your life to save me!\

\
Fry! Stay back! He's too powerful! That's right, baby. I ain't your loverboy Flexo, the guy you love so much. You even love anyone pretending to be him! You, minion. Lift my arm. AFTER HIM! When will that be?\
\

1. All I want is to be a monkey of moderate intelligence who wears a suit… that's why I'm transferring to business school!\
2. Leela, Bender, we're going grave robbing.\
3. A true inspiration for the children.\
   \

### Would you censor the Venus de Venus just because you can see her spewers?\

\
And then the battle's not so bad? I don't 'need' to drink. I can quit anytime I want! Why would a robot need to drink? A true inspiration for the children. You can crush me but you can't crush my spirit!\
\

- Is today's hectic lifestyle making you tense and impatient?\
- Ow, my spirit!\
- This opera's as lousy as it is brilliant! Your lyrics lack subtlety. You can't just have your characters announce how they feel. That makes me feel angry!\
  \
  You lived before you met me?! With a warning label this big, you know they gotta be fun! Wow! A superpowers drug you can just rub onto your skin? You'd think it would be something you'd have to freebase.\
  \
  It's a T. It goes "tuh". Oh, I think we should just stay friends. Yes. You gave me a dollar and some candy. Tell her you just want to talk. It has nothing to do with mating. Fry! Stay back! He's too powerful!\
  \
  We're also Santa Claus! I guess because my parents keep telling me to be more ladylike. As though! I decline the title of Iron Cook and accept the lesser title of Zinc Saucier, which I just made up. Uhh… also, comes with double prize money.\
  \
  Good man. Nixon's pro-war and pro-family. Yes. You gave me a dollar and some candy. Bender! Ship! Stop bickering or I'm going to come back there and change your opinions manually! That's the ONLY thing about being a slave.\
  \
  Fry, we have a crate to deliver. And remember, don't do anything that affects anything, unless it turns out you were supposed to, in which case, for the love of God, don't not do it! I never loved you.\
  \
  Fry! Stay back! He's too powerful! One hundred dollars. Whoa a real live robot; or is that some kind of cheesy New Year's costume? I haven't felt much of anything since my guinea pig died. WINDMILLS DO NOT WORK THAT WAY! GOOD NIGHT!\
  \
  Okay, I like a challenge. Then we'll go with that data file! I didn't ask for a completely reasonable excuse! I asked you to get busy! Is the Space Pope reptilian!? Yes, I saw. You were doing well, until everyone died.\
  \
  Ask her how her day was. Do a flip! In your time, yes, but nowadays shut up! Besides, these are adult stemcells, harvested from perfectly healthy adults whom I killed for their stemcells. Have you ever tried just turning off the TV, sitting down with your children, and hitting them?\
  \
  I'm just glad my fat, ugly mama isn't alive to see this day. I am Singing Wind, Chief of the Martians. Interesting. No, wait, the other thing: tedious. Hey, you add a one and two zeros to that or we walk!\
  \
  Dear God, they'll be killed on our doorstep! And there's no trash pickup until January 3rd. Why yes! Thanks for noticing. You don't know how to do any of those. Well I'da done better, but it's plum hard pleading a case while awaiting trial for that there incompetence.\
  \
  Who's brave enough to fly into something we all keep calling a death sphere? Yep, I remember. They came in last at the Olympics, then retired to promote alcoholic beverages! It doesn't look so shiny to me.
