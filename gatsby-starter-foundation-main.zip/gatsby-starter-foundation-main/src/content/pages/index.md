---
template: index-page
slug: /
title: Wyatt Morriss
tagline: Graphic Designer
featuredImage: /assets/toa-heftiba-0rlfirsdvzu-unsplash.jpg
cta:
  ctaText: Know more
  ctaLink: /about
---

He is a award winning gaming graphic designer, based in sunny side of California. Working as Principal designer at Bethesda
